let textFirstName = $("#textFirstName");
let textLastName = $("#textLastName");
let textemdil = $("#textemdil")
let textPassword = $("#textPassword");
let phoneNumber = $("#phoneNumber");

let textfirstnamepara = $("#textfirstnamepara");
let textlastnamepara = $("#textlastnamepara");
let textemailpara = $("#textemailpara")
let textpassworldpara = $("#textpassworldpara");
let numberpara = $("#numberpara");

let textFirstNameRegEx = /^([a-zA-Z]{2,30})$/;
let textLastNameRegEx = /^([a-zA-Z]{2,30})$/;
let textEmailRegEx = /^\b[a-z0-9._%-]+@[a-z0-9.-]+\.[A-Z]{2,18}\b$/i;
let textPasswordRegEx = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,12}$/;
let textPhoneRegEx = /^([0-9]{10})$/;

$(document).ready(function () {
    //validation code for First Name
    //===============================
    textFirstName.focus(function () { 
        $(this).css("background-color", "#999a");       
    });
    textFirstName.blur(function () {           
        $(this).css("background-color", "#fff");       
        textfirstnamepara.empty();
        if (textFirstName.val() == "" || textFirstName.val() == null) {
            textfirstnamepara.html(" * First Name required");
        }
        //check the First Name is Valid or Not
        else{
            if (!textFirstName.val().match(textFirstNameRegEx)) {
                textfirstnamepara.html(" * Invalid Name");
            }
        }
    });

    //keybord key press event
    // textFirstName.keypress(function(){
    //     alert(textFirstName.val());
    // });

    //validation code for Last Name
    //===============================

    textLastName.focus(function () { 
       $(this).css("background-color", "#999a");       
    });
    textLastName.blur(function () { 
        $(this).css("background-color", "#fff");       
        textlastnamepara.empty();          
        if (textLastName.val() == "" || textLastName.val() == null) {
            textlastnamepara.html(" * First Name required");
        }
        //check the First Name is Valid or Not
        else{
            if (!textLastName.val().match(textLastNameRegEx)) {
                textlastnamepara.html(" * Invalid Name");
            }
        }
    });

    //validation code for Email
    //===============================

    textemdil.focus(function () { 
       $(this).css("background-color", "#999a");       
    });
    textemdil.blur(function () { 
        $(this).css("background-color", "#fff");       
        textemailpara.empty();          
        if (textemdil.val() == "" || textemdil.val() == null) {
            textemailpara.html(" * First Name required");
        }
        //check the First Name is Valid or Not
        else{
            if (!textemdil.val().match(textEmailRegEx)) {
                textemailpara.html(" * Invalid Name");
            }
        }
    });

    //validation code for Password
    //==================================

    textPassword.focus(function () { 
       $(this).css("background-color", "#999a");       
    });
    textPassword.blur(function () {  
        $(this).css("background-color", "#fff");       

        textpassworldpara.empty();         
        if (textPassword.val() == "" || textPassword.val() == null) {
            textpassworldpara.html(" * First Name required");
        }
        //check the First Name is Valid or Not
        else{
            if (!textPassword.val().match(textPasswordRegEx)) {
                textpassworldpara.html(" * Invalid Name");
            }
        }
    });

    //validation code for Phone Number
    //==================================
    
    phoneNumber.focus(function () { 
       $(this).css("background-color", "#999a");       
    });
    phoneNumber.blur(function () {   
        $(this).css("background-color", "#fff");       

        numberpara.empty();        
        if (phoneNumber.val() == "" || phoneNumber.val() == null) {
            numberpara.html(" * First Name required");
        }
        //check the First Name is Valid or Not
        else{
            if (!phoneNumber.val().match(textPhoneRegEx)) {
                numberpara.html(" * Invalid Name");
            }
        }
    });
});